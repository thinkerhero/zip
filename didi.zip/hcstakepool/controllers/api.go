package controllers

import (
	"github.com/coolsnady/hcstakepool/system"
)

type ApiController struct {
	system.Controller
}
